#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
main.py - Основной модуль приложения

Этот модуль организует запуск всего приложения, инициализирует пользовательский интерфейс (GUI)
и объединяет работу всех модулей (калибровка, обработка изображений, сбор данных, анализ,
рабочий режим, передача данных).
"""

import sys
import os
import cv2
import numpy as np
import logging
import json
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QSlider, QSpinBox, QDoubleSpinBox,
    QComboBox, QCheckBox, QRadioButton, QButtonGroup, QGroupBox, QLineEdit,
    QMessageBox, QSplitter, QFrame
)
from PyQt5.QtGui import QImage, QPixmap, QFont
from PyQt5.QtCore import Qt, QTimer, pyqtSlot

# Импортируем модули приложения
from variables import *
from calibration import CalibrationManager
from computer_vision import ObjectDetector
from data_collection import process_unlabeled_objects, extract_roi, label_object_composite, save_object_data
from analysis import load_and_process_data, analyze_data, get_feature_ranges
from working_mode import run_working_mode, get_video_properties
from robot_comm import RobotCommunicator

# Настройка логирования
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.ERROR,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class MainWindow(QMainWindow):
    """
    Главное окно приложения с вкладками для разных режимов работы.
    """
    
    def __init__(self):
        super().__init__()
        
        # Инициализация компонентов
        self.calibration_manager = CalibrationManager()
        self.object_detector = ObjectDetector()
        self.robot_communicator = RobotCommunicator()
        
        # Флаги состояния
        self.is_running = False
        self.current_mode = None
        self.video_source = None
        self.cap = None
        
        # Настройка интерфейса
        self.init_ui()
        
        # Проверка калибровки при запуске
        self.check_calibration_on_startup()
    
    def init_ui(self):
        """
        Инициализирует пользовательский интерфейс.
        """
        # Настройка главного окна
        self.setWindowTitle("Computer Vision Application")
        self.setGeometry(100, 100, 1200, 800)
        
        # Создаем центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Создаем основной макет
        main_layout = QVBoxLayout(central_widget)
        
        # Создаем виджет с вкладками
        self.tabs = QTabWidget()
        
        # Создаем вкладки для разных режимов
        self.tab_calibration = QWidget()
        self.tab_data_collection = QWidget()
        self.tab_analysis = QWidget()
        self.tab_working = QWidget()
        self.tab_settings = QWidget()
        
        # Добавляем вкладки в виджет
        self.tabs.addTab(self.tab_calibration, "Калибровка")
        self.tabs.addTab(self.tab_data_collection, "Сбор данных")
        self.tabs.addTab(self.tab_analysis, "Анализ")
        self.tabs.addTab(self.tab_working, "Рабочий режим")
        self.tabs.addTab(self.tab_settings, "Настройки")
        
        # Инициализируем содержимое вкладок
        self.init_calibration_tab()
        self.init_data_collection_tab()
        self.init_analysis_tab()
        self.init_working_tab()
        self.init_settings_tab()
        
        # Добавляем виджет с вкладками в основной макет
        main_layout.addWidget(self.tabs)
        
        # Создаем строку состояния
        self.statusBar().showMessage("Готов к работе")
        
        # Создаем таймер для обновления видео
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        
        # Подключаем сигнал изменения вкладки
        self.tabs.currentChanged.connect(self.on_tab_changed)
    
    def init_calibration_tab(self):
        """
        Инициализирует вкладку калибровки.
        """
        # Создаем макет для вкладки
        layout = QVBoxLayout(self.tab_calibration)
        
        # Создаем верхнюю панель с кнопками
        top_panel = QHBoxLayout()
        
        # Кнопка для запуска калибровки
        self.btn_start_calibration = QPushButton("Запустить калибровку")
        self.btn_start_calibration.clicked.connect(self.on_start_calibration)
        top_panel.addWidget(self.btn_start_calibration)
        
        # Кнопка для сброса калибровки
        self.btn_reset_calibration = QPushButton("Сбросить калибровку")
        self.btn_reset_calibration.clicked.connect(self.on_reset_calibration)
        top_panel.addWidget(self.btn_reset_calibration)
        
        # Кнопка для сохранения калибровки
        self.btn_save_calibration = QPushButton("Сохранить калибровку")
        self.btn_save_calibration.clicked.connect(self.on_save_calibration)
        self.btn_save_calibration.setEnabled(False)
        top_panel.addWidget(self.btn_save_calibration)
        
        # Кнопка для генерации доски ChArUco
        self.btn_generate_board = QPushButton("Сгенерировать доску ChArUco")
        self.btn_generate_board.clicked.connect(self.on_generate_board)
        top_panel.addWidget(self.btn_generate_board)
        
        # Добавляем верхнюю панель в макет
        layout.addLayout(top_panel)
        
        # Создаем панель для выбора источника видео
        source_panel = QHBoxLayout()
        
        # Группа радиокнопок для выбора источника
        self.source_group = QButtonGroup()
        
        # Радиокнопка для выбора камеры
        self.radio_camera = QRadioButton("Камера")
        self.radio_camera.setChecked(True)
        self.source_group.addButton(self.radio_camera, 0)
        source_panel.addWidget(self.radio_camera)
        
        # Радиокнопка для выбора видеофайла
        self.radio_video = QRadioButton("Видеофайл")
        self.source_group.addButton(self.radio_video, 1)
        source_panel.addWidget(self.radio_video)
        
        # Поле для ввода пути к видеофайлу
        self.txt_calibration_video_path = QLineEdit()
        self.txt_calibration_video_path.setPlaceholderText("Путь к видеофайлу для калибровки")
        self.txt_calibration_video_path.setEnabled(False)
        source_panel.addWidget(self.txt_calibration_video_path)
        
        # Кнопка для выбора видеофайла
        self.btn_browse_calibration_video = QPushButton("Обзор...")
        self.btn_browse_calibration_video.clicked.connect(self.on_browse_calibration_video)
        self.btn_browse_calibration_video.setEnabled(False)
        source_panel.addWidget(self.btn_browse_calibration_video)
        
        # Добавляем панель выбора источника в макет
        layout.addLayout(source_panel)
        
        # Подключаем сигналы радиокнопок
        self.radio_camera.toggled.connect(self.on_source_toggled)
        self.radio_video.toggled.connect(self.on_source_toggled)
        
        # Создаем метку для отображения видео
        self.lbl_calibration_video = QLabel()
        self.lbl_calibration_video.setAlignment(Qt.AlignCenter)
        self.lbl_calibration_video.setMinimumSize(640, 480)
        self.lbl_calibration_video.setStyleSheet("background-color: black;")
        layout.addWidget(self.lbl_calibration_video)
        
        # Создаем метку для отображения статуса калибровки
        self.lbl_calibration_status = QLabel("Статус калибровки: Не выполнена")
        layout.addWidget(self.lbl_calibration_status)
        
        # Обновляем статус калибровки
        self.update_calibration_status()
    
    def init_data_collection_tab(self):
        """
        Инициализирует вкладку сбора данных.
        """
        # Создаем макет для вкладки
        layout = QVBoxLayout(self.tab_data_collection)
        
        # Создаем верхнюю панель с кнопками
        top_panel = QHBoxLayout()
        
        # Кнопка для запуска сбора данных
        self.btn_start_collection = QPushButton("Запустить сбор данных")
        self.btn_start_collection.clicked.connect(self.on_start_collection)
        top_panel.addWidget(self.btn_start_collection)
        
        # Кнопка для остановки сбора данных
        self.btn_stop_collection = QPushButton("Остановить сбор данных")
        self.btn_stop_collection.clicked.connect(self.on_stop_collection)
        self.btn_stop_collection.setEnabled(False)
        top_panel.addWidget(self.btn_stop_collection)
        
        # Добавляем верхнюю панель в макет
        layout.addLayout(top_panel)
        
        # Создаем панель для выбора источника видео
        source_panel = QHBoxLayout()
        
        # Группа радиокнопок для выбора источника
        self.collection_source_group = QButtonGroup()
        
        # Радиокнопка для выбора камеры
        self.radio_collection_camera = QRadioButton("Камера")
        self.radio_collection_camera.setChecked(True)
        self.collection_source_group.addButton(self.radio_collection_camera, 0)
        source_panel.addWidget(self.radio_collection_camera)
        
        # Радиокнопка для выбора видеофайла
        self.radio_collection_video = QRadioButton("Видеофайл")
        self.collection_source_group.addButton(self.radio_collection_video, 1)
        source_panel.addWidget(self.radio_collection_video)
        
        # Поле для ввода пути к видеофайлу
        self.txt_collection_video_path = QLineEdit()
        self.txt_collection_video_path.setPlaceholderText("Путь к видеофайлу для сбора данных")
        self.txt_collection_video_path.setEnabled(False)
        source_panel.addWidget(self.txt_collection_video_path)
        
        # Кнопка для выбора видеофайла
        self.btn_browse_collection_video = QPushButton("Обзор...")
        self.btn_browse_collection_video.clicked.connect(self.on_browse_collection_video)
        self.btn_browse_collection_video.setEnabled(False)
        source_panel.addWidget(self.btn_browse_collection_video)
        
        # Добавляем панель выбора источника в макет
        layout.addLayout(source_panel)
        
        # Подключаем сигналы радиокнопок
        self.radio_collection_camera.toggled.connect(self.on_collection_source_toggled)
        self.radio_collection_video.toggled.connect(self.on_collection_source_toggled)
        
        # Создаем метку для отображения видео
        self.lbl_collection_video = QLabel()
        self.lbl_collection_video.setAlignment(Qt.AlignCenter)
        self.lbl_collection_video.setMinimumSize(640, 480)
        self.lbl_collection_video.setStyleSheet("background-color: black;")
        layout.addWidget(self.lbl_collection_video)
        
        # Создаем метку для отображения статуса сбора данных
        self.lbl_collection_status = QLabel("Статус сбора данных: Не запущен")
        layout.addWidget(self.lbl_collection_status)
    
    def init_analysis_tab(self):
        """
        Инициализирует вкладку анализа данных.
        """
        # Создаем макет для вкладки
        layout = QVBoxLayout(self.tab_analysis)
        
        # Создаем верхнюю панель с элементами управления
        top_panel = QHBoxLayout()
        
        # Метка для выбора файла
        top_panel.addWidget(QLabel("Выберите файл данных:"))
        
        # Выпадающий список для выбора файла
        self.cmb_analysis_file = QComboBox()
        self.cmb_analysis_file.setMinimumWidth(300)
        top_panel.addWidget(self.cmb_analysis_file)
        
        # Кнопка для обновления списка файлов
        self.btn_refresh_files = QPushButton("Обновить список")
        self.btn_refresh_files.clicked.connect(self.on_refresh_files)
        top_panel.addWidget(self.btn_refresh_files)
        
        # Кнопка для анализа данных
        self.btn_analyze_data = QPushButton("Анализировать данные")
        self.btn_analyze_data.clicked.connect(self.on_analyze_data)
        top_panel.addWidget(self.btn_analyze_data)
        
        # Кнопка для генерации диапазонов
        self.btn_generate_ranges = QPushButton("Сгенерировать диапазоны")
        self.btn_generate_ranges.clicked.connect(self.on_generate_ranges)
        top_panel.addWidget(self.btn_generate_ranges)
        
        # Добавляем верхнюю панель в макет
        layout.addLayout(top_panel)
        
        # Создаем метку для отображения результатов анализа
        self.lbl_analysis_results = QLabel("Выберите файл и нажмите 'Анализировать данные'")
        self.lbl_analysis_results.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.lbl_analysis_results.setWordWrap(True)
        self.lbl_analysis_results.setMinimumHeight(400)
        self.lbl_analysis_results.setStyleSheet("background-color: white; padding: 10px;")
        layout.addWidget(self.lbl_analysis_results)
        
        # Обновляем список файлов
        self.on_refresh_files()
    
    def init_working_tab(self):
        """
        Инициализирует вкладку рабочего режима.
        """
        # Создаем макет для вкладки
        layout = QVBoxLayout(self.tab_working)
        
        # Создаем верхнюю панель с кнопками
        top_panel = QHBoxLayout()
        
        # Кнопка для запуска рабочего режима
        self.btn_start_working = QPushButton("Запустить рабочий режим")
        self.btn_start_working.clicked.connect(self.on_start_working)
        top_panel.addWidget(self.btn_start_working)
        
        # Кнопка для остановки рабочего режима
        self.btn_stop_working = QPushButton("Остановить рабочий режим")
        self.btn_stop_working.clicked.connect(self.on_stop_working)
        self.btn_stop_working.setEnabled(False)
        top_panel.addWidget(self.btn_stop_working)
        
        # Флажок для отправки данных на робота
        self.chk_send_to_robot = QCheckBox("Отправлять данные на робота")
        top_panel.addWidget(self.chk_send_to_robot)
        
        # Добавляем верхнюю панель в макет
        layout.addLayout(top_panel)
        
        # Создаем панель для выбора источника видео
        source_panel = QHBoxLayout()
        
        # Группа радиокнопок для выбора источника
        self.working_source_group = QButtonGroup()
        
        # Радиокнопка для выбора камеры
        self.radio_working_camera = QRadioButton("Камера")
        self.radio_working_camera.setChecked(True)
        self.working_source_group.addButton(self.radio_working_camera, 0)
        source_panel.addWidget(self.radio_working_camera)
        
        # Радиокнопка для выбора видеофайла
        self.radio_working_video = QRadioButton("Видеофайл")
        self.working_source_group.addButton(self.radio_working_video, 1)
        source_panel.addWidget(self.radio_working_video)
        
        # Поле для ввода пути к видеофайлу
        self.txt_working_video_path = QLineEdit()
        self.txt_working_video_path.setPlaceholderText("Путь к видеофайлу для обработки")
        self.txt_working_video_path.setEnabled(False)
        source_panel.addWidget(self.txt_working_video_path)
        
        # Кнопка для выбора видеофайла
        self.btn_browse_working_video = QPushButton("Обзор...")
        self.btn_browse_working_video.clicked.connect(self.on_browse_working_video)
        self.btn_browse_working_video.setEnabled(False)
        source_panel.addWidget(self.btn_browse_working_video)
        
        # Добавляем панель выбора источника в макет
        layout.addLayout(source_panel)
        
        # Подключаем сигналы радиокнопок
        self.radio_working_camera.toggled.connect(self.on_working_source_toggled)
        self.radio_working_video.toggled.connect(self.on_working_source_toggled)
        
        # Создаем метку для отображения видео
        self.lbl_working_video = QLabel()
        self.lbl_working_video.setAlignment(Qt.AlignCenter)
        self.lbl_working_video.setMinimumSize(640, 480)
        self.lbl_working_video.setStyleSheet("background-color: black;")
        layout.addWidget(self.lbl_working_video)
        
        # Создаем метку для отображения статуса рабочего 
(Content truncated due to size limit. Use line ranges to read in chunks)